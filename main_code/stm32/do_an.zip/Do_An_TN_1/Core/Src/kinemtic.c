/*
 * kinemtic.c
 *
 *  Created on: Apr 26, 2024
 *      Author: quang
 */


